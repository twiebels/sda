# SDA7-group-project

het groepsproject voor SDA team A7 bij Fontys Engineering

fakka g man
als je dit leest ben je cool


test dit vanuit vsc
